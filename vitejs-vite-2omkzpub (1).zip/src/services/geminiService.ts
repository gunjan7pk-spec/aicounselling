export async function analyzeCareer(prompt: string) {
  return {
    summary: 'Gemini integration will be connected in the next step.',
  };
}
