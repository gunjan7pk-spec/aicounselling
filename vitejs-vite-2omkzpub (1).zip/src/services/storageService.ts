import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

import { app } from '../firebase';

const storage = getStorage(app);

export async function uploadResume(file: File) {
  const fileRef = ref(storage, `resumes/${Date.now()}-${file.name}`);

  await uploadBytes(fileRef, file);

  return await getDownloadURL(fileRef);
}
