import { getFirestore, collection, addDoc, getDocs } from 'firebase/firestore';

import { app } from '../firebase';

const db = getFirestore(app);

export async function saveAssessment(data: any) {
  return await addDoc(collection(db, 'assessments'), data);
}

export async function getAssessments() {
  const snapshot = await getDocs(collection(db, 'assessments'));

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));
}
