export interface CareerResult {
  title: string;
  match: string;
  reason: string;
}

export function calculateCareerMatch(
  answers: Record<string, any>
): CareerResult[] {
  let softwareScore = 50;
  let dataScore = 50;
  let aiScore = 50;
  let productScore = 50;

  const answerText = JSON.stringify(answers).toLowerCase();

  // Programming / coding related

  if (
    answerText.includes('coding') ||
    answerText.includes('programming') ||
    answerText.includes('software') ||
    answerText.includes('development') ||
    answerText.includes('react') ||
    answerText.includes('javascript')
  ) {
    softwareScore += 35;
  }

  // Data related

  if (
    answerText.includes('data') ||
    answerText.includes('analysis') ||
    answerText.includes('analytics') ||
    answerText.includes('sql')
  ) {
    dataScore += 35;
  }

  // AI related

  if (
    answerText.includes('ai') ||
    answerText.includes('machine') ||
    answerText.includes('artificial') ||
    answerText.includes('python')
  ) {
    aiScore += 35;
  }

  // Management related

  if (
    answerText.includes('management') ||
    answerText.includes('business') ||
    answerText.includes('leader') ||
    answerText.includes('product')
  ) {
    productScore += 35;
  }

  const results: CareerResult[] = [
    {
      title: 'Software Engineer',
      match: `${Math.min(softwareScore, 99)}%`,
      reason: 'Strong match for coding, technology and problem solving skills.',
    },

    {
      title: 'Data Analyst',
      match: `${Math.min(dataScore, 99)}%`,
      reason: 'Good match for analytical thinking and data-driven work.',
    },

    {
      title: 'AI Engineer',
      match: `${Math.min(aiScore, 99)}%`,
      reason: 'Suitable for AI, machine learning and automation interests.',
    },

    {
      title: 'Product Manager',
      match: `${Math.min(productScore, 99)}%`,
      reason: 'Good fit for business thinking and leadership skills.',
    },
  ];

  return results.sort((a, b) => parseInt(b.match) - parseInt(a.match));
}
