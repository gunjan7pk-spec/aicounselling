import type { Answer } from '../types/Assessment';

export function calculateResults(answers: Answer[]) {
  const categories: Record<string, number> = {};

  answers.forEach((answer) => {
    categories[answer.category] =
      (categories[answer.category] || 0) + answer.score;
  });

  const totalScore = answers.reduce((sum, a) => sum + a.score, 0);

  const careers = [
    {
      title: 'Software Engineer',
      confidence: categories['Technology'] * 4,
      salary: '₹8-25 LPA',
    },
    {
      title: 'AI Engineer',
      confidence:
        (categories['Technology'] + categories['Problem Solving']) * 2,
      salary: '₹12-35 LPA',
    },
    {
      title: 'Data Scientist',
      confidence: (categories['Mathematics'] + categories['Technology']) * 2,
      salary: '₹10-30 LPA',
    },
    {
      title: 'Product Manager',
      confidence: (categories['Leadership'] + categories['Business']) * 2,
      salary: '₹15-40 LPA',
    },
    {
      title: 'UI UX Designer',
      confidence: (categories['Creativity'] + categories['Communication']) * 2,
      salary: '₹7-18 LPA',
    },
  ];

  careers.sort((a, b) => b.confidence - a.confidence);

  return {
    totalScore,
    categories,
    careers,
  };
}
