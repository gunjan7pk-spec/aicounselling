import mammoth from 'mammoth';

export async function extractResumeText(file: File) {
  const extension = file.name.split('.').pop()?.toLowerCase();

  if (extension === 'txt') {
    return await file.text();
  }

  if (extension === 'docx') {
    const arrayBuffer = await file.arrayBuffer();

    const result = await mammoth.extractRawText({
      arrayBuffer,
    });

    return result.value;
  }

  if (extension === 'pdf') {
    return 'PDF extraction will be added in the next step.';
  }

  return '';
}
