import { Routes, Route } from 'react-router-dom';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Assessment from './pages/Assessment';
import ResumeAnalyzer from './pages/ResumeAnalyzer';
import Recommendations from './pages/Recommendations';
import Profile from './pages/Profile';
import Results from './pages/Results';
import Roadmap from './pages/Roadmap';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      <Route path="/Login" element={<Login />} />

      <Route path="/Register" element={<Register />} />

      <Route path="/dashboard" element={<Dashboard />} />

      <Route path="/Assessment" element={<Assessment />} />

      <Route path="/Results" element={<Results />} />

      <Route path="/ResumeAnalyzer" element={<ResumeAnalyzer />} />

      <Route path="/Recommendations" element={<Recommendations />} />

      <Route path="/profile" element={<Profile />} />
      <Route path="/roadmap" element={<Roadmap />} />
    </Routes>
  );
}
