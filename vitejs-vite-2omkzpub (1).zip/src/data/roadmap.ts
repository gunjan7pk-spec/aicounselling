import  type { RoadmapData } from '../types/roadmap';

export const roadmapData: Record<string, RoadmapData> = {
  'AI Engineer': {
    title: 'AI Engineer',

    match: 96,

    salary: '₹12–35 LPA',

    growth: 'Excellent',

    skills: [
      'Python',
      'C++',
      'Data Structures',
      'Algorithms',
      'Git',
      'GitHub',
      'SQL',
      'Machine Learning',
      'Deep Learning',
      'TensorFlow',
      'PyTorch',
      'OpenCV',
      'Pandas',
      'NumPy',
      'Scikit-Learn',
      'FastAPI',
      'Docker',
      'AWS',
      'Linux',
      'Problem Solving',
    ],

    semesters: [
      {
        semester: 'Semester 1',
        topics: [
          'Programming Fundamentals',
          'C Programming',
          'Flowcharts',
          'Git & GitHub',
          'Problem Solving',
        ],
      },

      {
        semester: 'Semester 2',
        topics: [
          'Python',
          'Object Oriented Programming',
          'Data Structures',
          'Algorithms',
          'SQL',
        ],
      },

      {
        semester: 'Semester 3',
        topics: [
          'Statistics',
          'Probability',
          'NumPy',
          'Pandas',
          'Data Visualization',
        ],
      },

      {
        semester: 'Semester 4',
        topics: [
          'Machine Learning',
          'Regression',
          'Classification',
          'Scikit-Learn',
          'Model Evaluation',
        ],
      },

      {
        semester: 'Semester 5',
        topics: ['Deep Learning', 'TensorFlow', 'PyTorch', 'CNN', 'RNN'],
      },

      {
        semester: 'Semester 6',
        topics: [
          'Computer Vision',
          'Natural Language Processing',
          'OpenCV',
          'FastAPI',
          'Flask',
        ],
      },

      {
        semester: 'Semester 7',
        topics: [
          'Docker',
          'AWS',
          'MLOps',
          'System Design',
          'Interview Preparation',
        ],
      },

      {
        semester: 'Semester 8',
        topics: [
          'Major Project',
          'CareerPilot AI',
          'Resume Building',
          'Mock Interviews',
          'Internship Applications',
        ],
      },
    ],

    projects: {
      beginner: [
        'Calculator App',
        'Portfolio Website',
        'Weather App',
        'Student Management System',
      ],

      intermediate: [
        'Movie Recommendation System',
        'Expense Tracker',
        'Face Detection System',
        'AI Chatbot',
      ],

      advanced: [
        'CareerPilot AI',
        'AI Resume Analyzer',
        'Medical Diagnosis AI',
        'Smart Interview Assistant',
      ],
    },

    certifications: [
      {
        name: 'Google AI Essentials',
        provider: 'Google',
        level: 'Beginner',
      },
      {
        name: 'TensorFlow Developer',
        provider: 'Google',
        level: 'Intermediate',
      },
      {
        name: 'AWS Machine Learning Specialty',
        provider: 'Amazon',
        level: 'Advanced',
      },
      {
        name: 'Microsoft Azure AI Engineer',
        provider: 'Microsoft',
        level: 'Advanced',
      },
    ],

    companies: [
      {
        name: 'Google',
        role: 'AI Engineer',
      },
      {
        name: 'Microsoft',
        role: 'Machine Learning Engineer',
      },
      {
        name: 'Amazon',
        role: 'Applied Scientist',
      },
      {
        name: 'Adobe',
        role: 'AI Developer',
      },
      {
        name: 'NVIDIA',
        role: 'Deep Learning Engineer',
      },
    ],

    resources: [
      {
        title: 'CS50',
        url: 'https://cs50.harvard.edu',
        type: 'Course',
      },
      {
        title: 'Python Official Documentation',
        url: 'https://python.org',
        type: 'Documentation',
      },
      {
        title: 'TensorFlow Documentation',
        url: 'https://tensorflow.org',
        type: 'Documentation',
      },
      {
        title: 'Kaggle',
        url: 'https://kaggle.com',
        type: 'Practice',
      },
    ],

    salaryTimeline: [
      {
        experience: 'Fresher',
        salary: '₹8–12 LPA',
      },
      {
        experience: '2 Years',
        salary: '₹15–20 LPA',
      },
      {
        experience: '5 Years',
        salary: '₹30–45 LPA',
      },
      {
        experience: '10+ Years',
        salary: '₹60+ LPA',
      },
    ],

    mentorTips: [
      'Master Python before learning Machine Learning.',
      'Practice DSA consistently.',
      'Build at least 10 real-world projects.',
      'Keep your GitHub profile active.',
      'Apply for internships from your second year onwards.',
    ],
  },
  'Software Engineer': {
    title: 'Software Engineer',

    match: 93,

    salary: '₹8–25 LPA',

    growth: 'High',

    skills: [
      'C++',
      'Java',
      'JavaScript',
      'TypeScript',
      'HTML',
      'CSS',
      'React',
      'Node.js',
      'Express',
      'MongoDB',
      'SQL',
      'Git',
      'GitHub',
      'REST APIs',
      'Docker',
      'AWS',
      'System Design',
      'Data Structures',
      'Algorithms',
      'Problem Solving',
    ],

    semesters: [
      {
        semester: 'Semester 1',
        topics: ['Programming Fundamentals', 'C++', 'Git', 'Problem Solving'],
      },

      {
        semester: 'Semester 2',
        topics: [
          'Object Oriented Programming',
          'Data Structures',
          'Algorithms',
          'SQL',
        ],
      },

      {
        semester: 'Semester 3',
        topics: ['HTML', 'CSS', 'JavaScript', 'Responsive Design'],
      },

      {
        semester: 'Semester 4',
        topics: ['React', 'TypeScript', 'Node.js', 'Express'],
      },

      {
        semester: 'Semester 5',
        topics: ['MongoDB', 'REST APIs', 'Authentication', 'JWT'],
      },

      {
        semester: 'Semester 6',
        topics: ['Docker', 'AWS', 'CI/CD', 'Testing'],
      },

      {
        semester: 'Semester 7',
        topics: [
          'System Design',
          'Low Level Design',
          'Advanced React',
          'Interview Preparation',
        ],
      },

      {
        semester: 'Semester 8',
        topics: [
          'Major Project',
          'CareerPilot AI',
          'Resume Building',
          'Placement Preparation',
        ],
      },
    ],

    projects: {
      beginner: ['Calculator', 'To-Do App', 'Weather App', 'Portfolio Website'],

      intermediate: [
        'Expense Tracker',
        'Blog Website',
        'Chat Application',
        'Movie App',
      ],

      advanced: [
        'CareerPilot AI',
        'E-Commerce Website',
        'Realtime Collaboration App',
        'Video Meeting Platform',
      ],
    },

    certifications: [
      {
        name: 'Meta Front-End Developer',
        provider: 'Meta',
        level: 'Intermediate',
      },
      {
        name: 'AWS Cloud Practitioner',
        provider: 'Amazon',
        level: 'Beginner',
      },
      {
        name: 'Microsoft Azure Developer',
        provider: 'Microsoft',
        level: 'Intermediate',
      },
      {
        name: 'Oracle Java Foundations',
        provider: 'Oracle',
        level: 'Intermediate',
      },
    ],

    companies: [
      {
        name: 'Google',
        role: 'Software Engineer',
      },
      {
        name: 'Microsoft',
        role: 'Software Engineer',
      },
      {
        name: 'Amazon',
        role: 'SDE',
      },
      {
        name: 'Adobe',
        role: 'Frontend Engineer',
      },
      {
        name: 'Atlassian',
        role: 'Backend Engineer',
      },
      {
        name: 'Infosys',
        role: 'Software Engineer',
      },
      {
        name: 'TCS',
        role: 'System Engineer',
      },
    ],

    resources: [
      {
        title: 'MDN Web Docs',
        url: 'https://developer.mozilla.org/',
        type: 'Documentation',
      },
      {
        title: 'React Documentation',
        url: 'https://react.dev',
        type: 'Documentation',
      },
      {
        title: 'Node.js Documentation',
        url: 'https://nodejs.org',
        type: 'Documentation',
      },
      {
        title: 'LeetCode',
        url: 'https://leetcode.com',
        type: 'Practice',
      },
    ],

    salaryTimeline: [
      {
        experience: 'Fresher',
        salary: '₹6–10 LPA',
      },
      {
        experience: '2 Years',
        salary: '₹12–18 LPA',
      },
      {
        experience: '5 Years',
        salary: '₹22–35 LPA',
      },
      {
        experience: '10+ Years',
        salary: '₹45+ LPA',
      },
    ],

    mentorTips: [
      'Practice DSA daily.',
      'Build full-stack projects.',
      'Master Git and GitHub.',
      'Contribute to open source.',
      'Prepare for coding interviews consistently.',
    ],
  },
  'Data Scientist': {
    title: 'Data Scientist',

    match: 91,

    salary: '₹10–30 LPA',

    growth: 'Excellent',

    skills: [
      'Python',
      'SQL',
      'Statistics',
      'Probability',
      'Machine Learning',
      'Deep Learning',
      'Pandas',
      'NumPy',
      'Matplotlib',
      'Seaborn',
      'Scikit-Learn',
      'TensorFlow',
      'Power BI',
      'Tableau',
      'Git',
      'Docker',
      'AWS',
      'Jupyter Notebook',
    ],

    semesters: [
      {
        semester: 'Semester 1',
        topics: ['Python Basics', 'Statistics', 'Problem Solving', 'Git'],
      },

      {
        semester: 'Semester 2',
        topics: ['SQL', 'NumPy', 'Pandas', 'Data Cleaning'],
      },

      {
        semester: 'Semester 3',
        topics: ['Data Visualization', 'Matplotlib', 'Seaborn', 'Power BI'],
      },

      {
        semester: 'Semester 4',
        topics: [
          'Machine Learning',
          'Regression',
          'Classification',
          'Scikit-Learn',
        ],
      },

      {
        semester: 'Semester 5',
        topics: ['Deep Learning', 'TensorFlow', 'PyTorch', 'Neural Networks'],
      },

      {
        semester: 'Semester 6',
        topics: [
          'Natural Language Processing',
          'Computer Vision',
          'Time Series',
          'Model Deployment',
        ],
      },

      {
        semester: 'Semester 7',
        topics: ['Big Data', 'Spark', 'AWS', 'Docker'],
      },

      {
        semester: 'Semester 8',
        topics: [
          'Capstone Project',
          'Resume Building',
          'Interview Preparation',
          'Placements',
        ],
      },
    ],

    projects: {
      beginner: [
        'Netflix Data Analysis',
        'COVID Dashboard',
        'Sales Dashboard',
        'Student Performance Analysis',
      ],

      intermediate: [
        'Customer Segmentation',
        'Movie Recommendation System',
        'Stock Price Prediction',
        'Spam Email Classifier',
      ],

      advanced: [
        'AI Resume Analyzer',
        'Fraud Detection System',
        'Medical Prediction AI',
        'House Price Prediction Platform',
      ],
    },

    certifications: [
      {
        name: 'IBM Data Science Professional',
        provider: 'IBM',
        level: 'Intermediate',
      },
      {
        name: 'Google Advanced Data Analytics',
        provider: 'Google',
        level: 'Intermediate',
      },
      {
        name: 'Microsoft Power BI Data Analyst',
        provider: 'Microsoft',
        level: 'Intermediate',
      },
      {
        name: 'AWS Machine Learning Specialty',
        provider: 'Amazon',
        level: 'Advanced',
      },
    ],

    companies: [
      {
        name: 'Google',
        role: 'Data Scientist',
      },
      {
        name: 'Microsoft',
        role: 'Data Scientist',
      },
      {
        name: 'Amazon',
        role: 'Business Intelligence Engineer',
      },
      {
        name: 'Flipkart',
        role: 'Data Analyst',
      },
      {
        name: 'Paytm',
        role: 'ML Engineer',
      },
      {
        name: 'ZS Associates',
        role: 'Data Scientist',
      },
    ],

    resources: [
      {
        title: 'Kaggle',
        url: 'https://www.kaggle.com',
        type: 'Practice',
      },
      {
        title: 'Pandas Documentation',
        url: 'https://pandas.pydata.org',
        type: 'Documentation',
      },
      {
        title: 'Scikit-Learn Documentation',
        url: 'https://scikit-learn.org',
        type: 'Documentation',
      },
      {
        title: 'TensorFlow Documentation',
        url: 'https://www.tensorflow.org',
        type: 'Documentation',
      },
    ],

    salaryTimeline: [
      {
        experience: 'Fresher',
        salary: '₹7–10 LPA',
      },
      {
        experience: '2 Years',
        salary: '₹12–18 LPA',
      },
      {
        experience: '5 Years',
        salary: '₹20–35 LPA',
      },
      {
        experience: '10+ Years',
        salary: '₹45+ LPA',
      },
    ],

    mentorTips: [
      'Master statistics before Machine Learning.',
      'Practice SQL every week.',
      'Solve Kaggle datasets regularly.',
      'Create an impressive portfolio.',
      'Learn model deployment using FastAPI.',
    ],
  },
  'UI/UX Designer': {
    title: 'UI/UX Designer',

    match: 88,

    salary: '₹7–18 LPA',

    growth: 'High',

    skills: [
      'Figma',
      'Adobe XD',
      'Photoshop',
      'Illustrator',
      'Wireframing',
      'Prototyping',
      'User Research',
      'Design Systems',
      'Typography',
      'Color Theory',
      'Responsive Design',
      'HTML',
      'CSS',
      'Accessibility',
      'Interaction Design',
      'Usability Testing',
    ],

    semesters: [
      {
        semester: 'Semester 1',
        topics: [
          'Design Fundamentals',
          'Color Theory',
          'Typography',
          'Visual Design',
        ],
      },

      {
        semester: 'Semester 2',
        topics: ['Figma', 'Wireframing', 'Low Fidelity Design', 'User Flows'],
      },

      {
        semester: 'Semester 3',
        topics: [
          'Prototyping',
          'Responsive Design',
          'Components',
          'Auto Layout',
        ],
      },

      {
        semester: 'Semester 4',
        topics: [
          'UX Research',
          'Personas',
          'User Journey',
          'Usability Testing',
        ],
      },

      {
        semester: 'Semester 5',
        topics: [
          'Design Systems',
          'Accessibility',
          'Micro Interactions',
          'Animation',
        ],
      },

      {
        semester: 'Semester 6',
        topics: ['HTML', 'CSS', 'Developer Handoff', 'Portfolio Design'],
      },

      {
        semester: 'Semester 7',
        topics: [
          'Case Studies',
          'Real Client Projects',
          'Interview Preparation',
        ],
      },

      {
        semester: 'Semester 8',
        topics: ['Final Portfolio', 'Resume', 'Placements', 'Freelancing'],
      },
    ],

    projects: {
      beginner: [
        'Landing Page Design',
        'Login Screen',
        'Dashboard UI',
        'Mobile App UI',
      ],

      intermediate: [
        'Food Delivery App',
        'Banking App',
        'Travel Website',
        'E-commerce UI',
      ],

      advanced: [
        'CareerPilot AI Design',
        'Complete Design System',
        'Healthcare App',
        'SaaS Dashboard',
      ],
    },

    certifications: [
      {
        name: 'Google UX Design Professional',
        provider: 'Google',
        level: 'Beginner',
      },
      {
        name: 'Adobe Certified Professional',
        provider: 'Adobe',
        level: 'Intermediate',
      },
      {
        name: 'Meta UX Design',
        provider: 'Meta',
        level: 'Intermediate',
      },
    ],

    companies: [
      {
        name: 'Google',
        role: 'Product Designer',
      },
      {
        name: 'Microsoft',
        role: 'UX Designer',
      },
      {
        name: 'Adobe',
        role: 'UI Designer',
      },
      {
        name: 'Zomato',
        role: 'Product Designer',
      },
      {
        name: 'Swiggy',
        role: 'UX Designer',
      },
    ],

    resources: [
      {
        title: 'Figma Learn',
        url: 'https://www.figma.com',
        type: 'Course',
      },
      {
        title: 'Nielsen Norman Group',
        url: 'https://www.nngroup.com',
        type: 'Articles',
      },
      {
        title: 'Dribbble',
        url: 'https://dribbble.com',
        type: 'Inspiration',
      },
      {
        title: 'Behance',
        url: 'https://www.behance.net',
        type: 'Portfolio',
      },
    ],

    salaryTimeline: [
      {
        experience: 'Fresher',
        salary: '₹5–8 LPA',
      },
      {
        experience: '2 Years',
        salary: '₹8–12 LPA',
      },
      {
        experience: '5 Years',
        salary: '₹15–22 LPA',
      },
      {
        experience: '10+ Years',
        salary: '₹30+ LPA',
      },
    ],

    mentorTips: [
      'Build a strong portfolio.',
      'Study real-world products daily.',
      'Practice user research.',
      'Master Figma components.',
      'Write detailed case studies.',
    ],
  },
};
