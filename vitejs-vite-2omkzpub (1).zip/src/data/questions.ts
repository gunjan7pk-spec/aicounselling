export interface Question {
  id: number;
  step: number;
  category: string;
  question: string;
  type: 'radio' | 'checkbox' | 'text' | 'rating';
  options?: string[];
}

export const questions: Question[] = [
  // -----------------------------
  // STEP 1 - PERSONAL
  // -----------------------------

  {
    id: 1,
    step: 1,
    category: 'Personal',
    question: 'What is your age group?',
    type: 'radio',
    options: ['16-18', '19-22', '23-26', '27+'],
  },

  {
    id: 2,
    step: 1,
    category: 'Personal',
    question: 'Which country are you from?',
    type: 'text',
  },

  {
    id: 3,
    step: 1,
    category: 'Personal',
    question: 'What is your highest qualification?',
    type: 'radio',
    options: ['High School', 'Diploma', 'Bachelor', 'Master', 'PhD'],
  },

  // -----------------------------
  // STEP 2 - EDUCATION
  // -----------------------------

  {
    id: 4,
    step: 2,
    category: 'Education',
    question: 'Which stream are you studying?',
    type: 'radio',
    options: [
      'Computer Science',
      'Arts',
      'Commerce',
      'Science',
      'Management',
      'Other',
    ],
  },

  {
    id: 5,
    step: 2,
    category: 'Education',
    question: 'Current Year?',
    type: 'radio',
    options: ['1st Year', '2nd Year', '3rd Year', '4th Year', 'Graduated'],
  },

  // -----------------------------
  // STEP 3 - TECHNICAL SKILLS
  // -----------------------------

  {
    id: 6,
    step: 3,
    category: 'Skills',
    question: 'Select your technical skills',
    type: 'checkbox',
    options: [
      'C',
      'C++',
      'Java',
      'Python',
      'JavaScript',
      'React',
      'Node.js',
      'SQL',
      'HTML',
      'CSS',
      'Git',
      'Excel',
    ],
  },

  // -----------------------------
  // STEP 4 - SOFT SKILLS
  // -----------------------------

  {
    id: 7,
    step: 4,
    category: 'Soft Skills',
    question: 'Select your strengths',
    type: 'checkbox',
    options: [
      'Communication',
      'Leadership',
      'Problem Solving',
      'Critical Thinking',
      'Teamwork',
      'Creativity',
      'Time Management',
    ],
  },

  // -----------------------------
  // STEP 5 - INTERESTS
  // -----------------------------

  {
    id: 8,
    step: 5,
    category: 'Interest',
    question: 'Which fields interest you?',
    type: 'checkbox',
    options: [
      'Artificial Intelligence',
      'Web Development',
      'App Development',
      'Cyber Security',
      'Cloud Computing',
      'Data Science',
      'Government Jobs',
      'Finance',
      'Marketing',
      'UI/UX Design',
    ],
  },

  // -----------------------------
  // STEP 6 - CAREER GOALS
  // -----------------------------

  {
    id: 9,
    step: 6,
    category: 'Career Goal',
    question: 'Where do you want to work?',
    type: 'radio',
    options: [
      'Google',
      'Microsoft',
      'Startup',
      'Government',
      'Remote',
      'Freelancing',
    ],
  },

  {
    id: 10,
    step: 6,
    category: 'Career Goal',
    question: 'Expected salary after 5 years?',
    type: 'radio',
    options: ['5 LPA', '10 LPA', '20 LPA', '30+ LPA'],
  },

  // -----------------------------
  // STEP 7 - PERSONALITY
  // -----------------------------

  {
    id: 11,
    step: 7,
    category: 'Personality',
    question: 'I enjoy solving complex problems.',
    type: 'rating',
  },

  {
    id: 12,
    step: 7,
    category: 'Personality',
    question: 'I enjoy leading a team.',
    type: 'rating',
  },

  {
    id: 13,
    step: 7,
    category: 'Personality',
    question: 'I like learning new technologies.',
    type: 'rating',
  },

  {
    id: 14,
    step: 7,
    category: 'Personality',
    question: 'I enjoy public speaking.',
    type: 'rating',
  },

  {
    id: 15,
    step: 7,
    category: 'Personality',
    question: 'I enjoy analytical thinking.',
    type: 'rating',
  },
];
