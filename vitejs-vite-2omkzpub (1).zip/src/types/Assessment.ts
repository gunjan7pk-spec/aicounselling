export interface Question {
  id: number;
  category: string;
  question: string;
}

export interface Answer {
  questionId: number;
  category: string;
  score: number;
}
