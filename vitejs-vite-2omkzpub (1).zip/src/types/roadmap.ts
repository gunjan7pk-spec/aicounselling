export interface Semester {
  semester: string;
  topics: string[];
}

export interface Projects {
  beginner: string[];
  intermediate: string[];
  advanced: string[];
}

export interface Certification {
  name: string;
  provider: string;
  level: string;
}

export interface Company {
  name: string;
  role: string;
}

export interface Resource {
  title: string;
  url: string;
  type: string;
}

export interface SalaryStep {
  experience: string;
  salary: string;
}

export interface RoadmapData {
  title: string;
  match: number;
  salary: string;
  growth: string;

  skills: string[];

  semesters: Semester[];

  projects: Projects;

  certifications: Certification[];

  companies: Company[];

  resources: Resource[];

  salaryTimeline: SalaryStep[];

  mentorTips: string[];
}
