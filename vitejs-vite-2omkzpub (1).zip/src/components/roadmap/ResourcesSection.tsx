import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { motion } from 'framer-motion';
import {
  FaYoutube,
  FaBook,
  FaCode,
  FaGlobe,
  FaExternalLinkAlt,
} from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

const resources = [
  {
    title: 'freeCodeCamp',
    type: 'YouTube',
    description: 'Complete programming, Python, JavaScript and AI tutorials.',
    icon: <FaYoutube />,
    color: '#FF0000',
    link: 'https://www.youtube.com/@freecodecamp',
  },
  {
    title: 'Coursera',
    type: 'Online Course',
    description:
      'Professional certificates from Google, IBM, Meta and Microsoft.',
    icon: <FaGlobe />,
    color: '#0056D2',
    link: 'https://www.coursera.org',
  },
  {
    title: 'GeeksforGeeks',
    type: 'Coding Practice',
    description:
      'Practice DSA, aptitude, interview questions and core subjects.',
    icon: <FaCode />,
    color: '#2F8D46',
    link: 'https://www.geeksforgeeks.org',
  },
  {
    title: 'MDN Web Docs',
    type: 'Documentation',
    description: 'Best documentation for HTML, CSS and JavaScript.',
    icon: <FaBook />,
    color: '#000000',
    link: 'https://developer.mozilla.org',
  },
  {
    title: 'Kaggle',
    type: 'AI Practice',
    description: 'Datasets, notebooks and machine learning competitions.',
    icon: <FaCode />,
    color: '#20BEFF',
    link: 'https://www.kaggle.com',
  },
  {
    title: 'GitHub',
    type: 'Projects',
    description: 'Build your portfolio and contribute to open-source projects.',
    icon: <FaGlobe />,
    color: '#24292F',
    link: 'https://github.com',
  },
];

export default function ResourcesSection({ roadmap }: Props) {
  return (
    <section className="resources-section">
      <div className="section-title">
        <h2>
          <FaBook />
          Learning Resources
        </h2>

        <p>
          Best platforms to become a <strong>{roadmap.title}</strong>.
        </p>
      </div>

      <div className="resource-grid">
        {resources.map((resource, index) => (
          <motion.div
            key={resource.title}
            className="resource-card"
            initial={{
              opacity: 0,
              y: 30,
            }}
            whileInView={{
              opacity: 1,
              y: 0,
            }}
            transition={{
              delay: index * 0.08,
            }}
            whileHover={{
              y: -10,
            }}
            viewport={{
              once: true,
            }}
          >
            <div
              className="resource-icon"
              style={{
                background: resource.color,
              }}
            >
              {resource.icon}
            </div>

            <span className="resource-type">{resource.type}</span>

            <h3>{resource.title}</h3>

            <p>{resource.description}</p>

            <a
              href={resource.link}
              target="_blank"
              rel="noopener noreferrer"
              className="resource-btn"
            >
              Visit Resource
              <FaExternalLinkAlt />
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
