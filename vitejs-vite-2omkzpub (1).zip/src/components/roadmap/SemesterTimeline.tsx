import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FaChevronDown,
  FaChevronUp,
  FaCheckCircle,
  FaRegCircle,
} from 'react-icons/fa';

interface Semester {
  semester: string;
  topics: string[];
}

interface Props {
  roadmap: {
    semesters: Semester[];
  };
}

export default function SemesterTimeline({ roadmap }: Props) {
  const [openSemester, setOpenSemester] = useState<number>(0);

  const [completed, setCompleted] = useState<Record<string, boolean>>({});

  const toggleTopic = (topic: string) => {
    setCompleted((prev) => ({
      ...prev,
      [topic]: !prev[topic],
    }));
  };

  return (
    <section className="timeline-section">
      <div className="section-header">
        <h2>Semester Roadmap</h2>

        <p>Follow each semester step-by-step to become placement ready.</p>
      </div>

      <div className="timeline">
        {roadmap.semesters.map((semester, index) => (
          <div className="timeline-item" key={semester.semester}>
            <div className="timeline-left">
              <div className="timeline-dot" />

              {index !== roadmap.semesters.length - 1 && (
                <div className="timeline-line" />
              )}
            </div>

            <div className="timeline-right">
              <motion.div whileHover={{ scale: 1.01 }} className="semester-box">
                <button
                  className="semester-header"
                  onClick={() =>
                    setOpenSemester(openSemester === index ? -1 : index)
                  }
                >
                  <div>
                    <h3>{semester.semester}</h3>

                    <span>{semester.topics.length} Topics</span>
                  </div>

                  {openSemester === index ? <FaChevronUp /> : <FaChevronDown />}
                </button>

                <AnimatePresence>
                  {openSemester === index && (
                    <motion.div
                      className="semester-content"
                      initial={{
                        height: 0,
                        opacity: 0,
                      }}
                      animate={{
                        height: 'auto',
                        opacity: 1,
                      }}
                      exit={{
                        height: 0,
                        opacity: 0,
                      }}
                      transition={{
                        duration: 0.35,
                      }}
                    >
                      {semester.topics.map((topic) => (
                        <div
                          key={topic}
                          className="topic-row"
                          onClick={() => toggleTopic(topic)}
                        >
                          {completed[topic] ? (
                            <FaCheckCircle className="completed-icon" />
                          ) : (
                            <FaRegCircle className="pending-icon" />
                          )}

                          <span>{topic}</span>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
