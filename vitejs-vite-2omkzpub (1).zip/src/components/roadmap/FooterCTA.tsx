import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  FaArrowRight,
  FaDownload,
  FaChartLine,
  FaRedoAlt,
  FaFileAlt,
} from 'react-icons/fa';

export default function FooterCTA() {
  const navigate = useNavigate();

  const handleDownload = () => {
    // TODO: Replace with PDF generation
    alert('PDF download will be available soon.');
  };

  return (
    <motion.section
      className="footer-cta"
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
    >
      <div className="footer-cta-content">
        <span className="footer-badge">🎯 CareerPilot AI</span>

        <h2>You're One Step Closer to Your Dream Career</h2>

        <p>
          Continue learning consistently, complete projects, practice
          interviews, and keep improving your resume. Every small step brings
          you closer to your dream job.
        </p>

        <div className="footer-actions">
          <button
            className="footer-primary-btn"
            onClick={() => navigate('/dashboard')}
          >
            <FaChartLine />
            Dashboard
          </button>

          <button
            className="footer-secondary-btn"
            onClick={() => navigate('/recommendations')}
          >
            <FaArrowRight />
            Recommendations
          </button>

          <button
            className="footer-secondary-btn"
            onClick={() => navigate('/assessment')}
          >
            <FaRedoAlt />
            Retake Assessment
          </button>

          <button
            className="footer-secondary-btn"
            onClick={() => navigate('/resume')}
          >
            <FaFileAlt />
            Resume Analyzer
          </button>

          <button className="footer-download-btn" onClick={handleDownload}>
            <FaDownload />
            Download PDF
          </button>
        </div>
      </div>
    </motion.section>
  );
}
