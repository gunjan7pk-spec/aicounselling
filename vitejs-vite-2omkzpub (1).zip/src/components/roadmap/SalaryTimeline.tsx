import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { motion } from 'framer-motion';
import { FaMoneyBillWave, FaArrowUp, FaBriefcase } from 'react-icons/fa';

interface Props {
  roadmap:  RoadmapData;
}

const salaryData = [
  {
    experience: 'Fresher',
    salary: '₹6–12 LPA',
    color: '#10b981',
  },
  {
    experience: '1-2 Years',
    salary: '₹10–18 LPA',
    color: '#3b82f6',
  },
  {
    experience: '3-5 Years',
    salary: '₹18–30 LPA',
    color: '#8b5cf6',
  },
  {
    experience: '5-8 Years',
    salary: '₹30–45 LPA',
    color: '#f59e0b',
  },
  {
    experience: '10+ Years',
    salary: '₹50 LPA+',
    color: '#ef4444',
  },
];

export default function SalaryTimeline({ roadmap }: Props) {
  return (
    <section className="salary-section">
      <div className="section-title">
        <h2>
          <FaMoneyBillWave />
          Salary Growth Timeline
        </h2>

        <p>
          Expected salary progression as a<strong> {roadmap.title}</strong>
        </p>
      </div>

      <div className="salary-timeline">
        {salaryData.map((item, index) => (
          <motion.div
            key={item.experience}
            className="salary-card"
            initial={{
              opacity: 0,
              y: 40,
            }}
            whileInView={{
              opacity: 1,
              y: 0,
            }}
            transition={{
              delay: index * 0.15,
            }}
            whileHover={{
              y: -10,
              scale: 1.03,
            }}
            viewport={{
              once: true,
            }}
          >
            <div
              className="salary-icon"
              style={{
                background: item.color,
              }}
            >
              <FaBriefcase />
            </div>

            <h3>{item.experience}</h3>

            <h2>{item.salary}</h2>

            <div className="salary-growth">
              <FaArrowUp />
              Career Growth
            </div>

            {index !== salaryData.length - 1 && <div className="salary-line" />}
          </motion.div>
        ))}
      </div>

      <motion.div
        className="salary-summary"
        initial={{
          opacity: 0,
        }}
        whileInView={{
          opacity: 1,
        }}
        transition={{
          delay: 0.4,
        }}
      >
        <h3>Current Recommendation</h3>

        <p>
          CareerPilot AI estimates an average salary of
          <strong> {roadmap.salary}</strong>
          based on your selected career path, skills, and current industry
          trends.
        </p>
      </motion.div>
    </section>
  );
}
