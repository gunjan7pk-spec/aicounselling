import { motion } from 'framer-motion';
import {
  FaChartLine,
  FaBriefcase,
  FaBullseye,
  FaArrowDown,
} from 'react-icons/fa';
import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}

export default function RoadmapHero({ roadmap }: Props) {
  return (
    <section className="roadmap-hero">
      <motion.div
        className="roadmap-hero-content"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <span className="hero-badge">🚀 Career Roadmap</span>

        <h1>{roadmap.title}</h1>

        <p>
          Follow this complete learning roadmap to become a successful{' '}
          <strong>{roadmap.title}</strong>. Learn the right skills, build
          projects, earn certifications, and prepare for placements.
        </p>

        <div className="hero-stats">
          <div className="hero-stat-card">
            <FaBullseye className="hero-icon" />

            <div>
              <span>Match Score</span>
              <h3>{roadmap.match}%</h3>
            </div>
          </div>

          <div className="hero-stat-card">
            <FaBriefcase className="hero-icon" />

            <div>
              <span>Expected Salary</span>
              <h3>{roadmap.salary}</h3>
            </div>
          </div>

          <div className="hero-stat-card">
            <FaChartLine className="hero-icon" />

            <div>
              <span>Growth</span>
              <h3>{roadmap.growth}</h3>
            </div>
          </div>
        </div>

        <motion.a
          href="#timeline"
          className="hero-scroll-btn"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Start Learning
          <FaArrowDown />
        </motion.a>
      </motion.div>
    </section>
  );
}
