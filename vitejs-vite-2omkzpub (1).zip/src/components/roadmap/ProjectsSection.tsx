import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaGithub, FaClock, FaCode, FaLaptopCode } from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

type Level = 'beginner' | 'intermediate' | 'advanced';

const projectConfig = {
  beginner: {
    title: '🟢 Beginner',
    color: '#10b981',
    duration: '1-2 Weeks',
    tech: ['HTML', 'CSS', 'JavaScript'],
  },
  intermediate: {
    title: '🟡 Intermediate',
    color: '#f59e0b',
    duration: '2-4 Weeks',
    tech: ['React', 'Node.js', 'API'],
  },
  advanced: {
    title: '🔴 Advanced',
    color: '#ef4444',
    duration: '1-2 Months',
    tech: ['AI', 'Firebase', 'Cloud'],
  },
};

export default function ProjectsSection({ roadmap }: Props) {
  const [activeTab, setActiveTab] = useState<Level>('beginner');

  const projects = roadmap.projects[activeTab];

  const config = projectConfig[activeTab];

  return (
    <section className="projects-section">
      <div className="section-title">
        <h2>
          <FaLaptopCode />
          Project Roadmap
        </h2>

        <p>Build these projects step by step to strengthen your portfolio.</p>
      </div>

      <div className="project-tabs">
        {(Object.keys(projectConfig) as Level[]).map((level) => (
          <button
            key={level}
            onClick={() => setActiveTab(level)}
            className={
              activeTab === level ? 'project-tab active' : 'project-tab'
            }
            style={{
              borderColor: projectConfig[level].color,
            }}
          >
            {projectConfig[level].title}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          className="project-grid"
          initial={{
            opacity: 0,
            y: 20,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          exit={{
            opacity: 0,
            y: -20,
          }}
          transition={{
            duration: 0.35,
          }}
        >
          {projects.map((project) => (
            <motion.div
              key={project}
              whileHover={{
                y: -10,
              }}
              className="project-card"
            >
              <div
                className="project-level"
                style={{
                  background: config.color,
                }}
              >
                {config.title}
              </div>

              <h3>{project}</h3>

              <div className="project-meta">
                <span>
                  <FaClock />

                  {config.duration}
                </span>
              </div>

              <div className="tech-stack">
                {config.tech.map((tech) => (
                  <span key={tech} className="tech-chip">
                    {tech}
                  </span>
                ))}
              </div>

              <div className="project-footer">
                <button className="github-btn">
                  <FaGithub />
                  GitHub
                </button>

                <button className="start-btn">
                  <FaCode />
                  Start
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}
