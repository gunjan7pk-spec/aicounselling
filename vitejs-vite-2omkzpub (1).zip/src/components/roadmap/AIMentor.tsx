import type  { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { motion } from 'framer-motion';
import {
  FaRobot,
  FaArrowRight,
  FaBrain,
  FaLightbulb,
  FaBriefcase,
  FaRocket,
} from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

export default function AIMentor({ roadmap }: Props) {
  const tips = [
    {
      icon: <FaBrain />,
      title: 'Master Core Skills',
      text: `Focus on ${roadmap.skills
        .slice(0, 3)
        .join(', ')} before learning advanced topics.`,
    },

    {
      icon: <FaRocket />,
      title: 'Build Projects',
      text: 'Complete at least 5 real-world projects to strengthen your portfolio.',
    },

    {
      icon: <FaBriefcase />,
      title: 'Internships',
      text: 'Start applying for internships after finishing your intermediate projects.',
    },

    {
      icon: <FaLightbulb />,
      title: 'Interview Preparation',
      text: 'Practice DSA, aptitude, communication and mock interviews every week.',
    },
  ];

  return (
    <section className="mentor-section">
      <motion.div
        className="mentor-card"
        initial={{
          opacity: 0,
          y: 50,
        }}
        whileInView={{
          opacity: 1,
          y: 0,
        }}
        transition={{
          duration: 0.6,
        }}
      >
        <div className="mentor-header">
          <div className="mentor-avatar">
            <FaRobot />
          </div>

          <div>
            <h2>CareerPilot AI Mentor</h2>

            <p>Personalized guidance based on your roadmap and career goal.</p>
          </div>
        </div>

        <div className="mentor-message">
          <h3>Hello 👋</h3>

          <p>
            Based on your <strong>{roadmap.match}%</strong> career match for{' '}
            <strong>{roadmap.title}</strong>, you're on a promising path. Focus
            on consistent learning, build projects, and apply for internships
            early.
          </p>
        </div>

        <div className="mentor-tips">
          {tips.map((tip, index) => (
            <motion.div
              key={index}
              className="mentor-tip"
              whileHover={{
                y: -8,
              }}
            >
              <div className="mentor-icon">{tip.icon}</div>

              <div>
                <h4>{tip.title}</h4>

                <p>{tip.text}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="daily-challenge">
          <h3>🔥 Today's Challenge</h3>

          <p>
            Solve <strong>2 DSA problems</strong>, revise one important concept,
            and spend <strong>30 minutes</strong>
            building your current project.
          </p>
        </div>

        <div className="mentor-actions">
          <button className="mentor-btn">
            Ask CareerPilot AI
            <FaArrowRight />
          </button>
        </div>
      </motion.div>
    </section>
  );
}
