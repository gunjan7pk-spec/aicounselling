import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { motion } from 'framer-motion';
import { FaCertificate, FaExternalLinkAlt, FaAward } from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

const certifications = [
  {
    title: 'Google AI Essentials',
    provider: 'Google',
    level: 'Beginner',
    duration: '10 Hours',
    color: '#4285F4',
  },
  {
    title: 'AWS Cloud Practitioner',
    provider: 'Amazon',
    level: 'Beginner',
    duration: '20 Hours',
    color: '#FF9900',
  },
  {
    title: 'TensorFlow Developer',
    provider: 'Google',
    level: 'Intermediate',
    duration: '35 Hours',
    color: '#FF6F00',
  },
  {
    title: 'Microsoft Azure AI Engineer',
    provider: 'Microsoft',
    level: 'Advanced',
    duration: '40 Hours',
    color: '#0078D4',
  },
  {
    title: 'IBM Data Science Professional',
    provider: 'IBM',
    level: 'Intermediate',
    duration: '45 Hours',
    color: '#1261FE',
  },
  {
    title: 'Meta Front-End Professional',
    provider: 'Meta',
    level: 'Intermediate',
    duration: '30 Hours',
    color: '#0866FF',
  },
];

export default function CertificationsSection({ roadmap }: Props) {
  return (
    <section className="certifications-section">
      <div className="section-title">
        <h2>
          <FaCertificate />
          Recommended Certifications
        </h2>

        <p>
          Industry-recognized certifications for becoming a{' '}
          <strong>{roadmap.title}</strong>.
        </p>
      </div>

      <div className="cert-grid">
        {certifications.map((cert, index) => (
          <motion.div
            key={index}
            className="cert-card"
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{
              delay: index * 0.08,
            }}
            whileHover={{
              y: -10,
            }}
            viewport={{ once: true }}
          >
            <div
              className="cert-icon"
              style={{
                background: cert.color,
              }}
            >
              <FaAward />
            </div>

            <h3>{cert.title}</h3>

            <p>{cert.provider}</p>

            <div className="cert-info">
              <span>{cert.level}</span>

              <span>{cert.duration}</span>
            </div>

            <button className="cert-btn">
              Learn More
              <FaExternalLinkAlt />
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
