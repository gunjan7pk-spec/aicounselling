import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { motion } from 'framer-motion';
import { FaCode, FaFire, FaCheckCircle } from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

const getSkillLevel = (index: number) => {
  const levels = [95, 90, 85, 80, 75, 70, 65, 60, 55, 50];

  return levels[index % levels.length];
};

const getDifficulty = (level: number) => {
  if (level >= 90)
    return {
      text: 'Essential',
      color: '#2563eb',
    };

  if (level >= 75)
    return {
      text: 'Important',
      color: '#f59e0b',
    };

  return {
    text: 'Optional',
    color: '#10b981',
  };
};

export default function SkillsSection({ roadmap }: Props) {
  return (
    <section className="skills-section">
      <div className="section-title">
        <h2>
          <FaCode />
          Required Skills
        </h2>

        <p>Master these technologies to become industry ready.</p>
      </div>

      <div className="skills-grid">
        {roadmap.skills.map((skill, index) => {
          const level = getSkillLevel(index);

          const badge = getDifficulty(level);

          return (
            <motion.div
              key={skill}
              className="skill-card"
              whileHover={{
                y: -8,
              }}
              initial={{
                opacity: 0,
                y: 20,
              }}
              whileInView={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                duration: 0.4,
              }}
              viewport={{
                once: true,
              }}
            >
              <div className="skill-header">
                <div className="skill-icon">
                  <FaFire />
                </div>

                <span
                  className="skill-badge"
                  style={{
                    background: badge.color,
                  }}
                >
                  {badge.text}
                </span>
              </div>

              <h3>{skill}</h3>

              <div className="skill-progress">
                <div
                  className="skill-progress-fill"
                  style={{
                    width: `${level}%`,
                  }}
                />
              </div>

              <div className="skill-footer">
                <span>{level}%</span>

                <FaCheckCircle />
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
