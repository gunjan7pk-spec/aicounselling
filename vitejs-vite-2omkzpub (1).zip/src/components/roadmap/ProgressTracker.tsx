import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}
import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { FaCheckCircle, FaRegCircle, FaTrophy, FaStar } from 'react-icons/fa';

interface Props {
  roadmap: RoadmapData;
}

export default function ProgressTracker({ roadmap }: Props) {
  const allTopics = roadmap.semesters.flatMap((semester) => semester.topics);

  const [completed, setCompleted] = useState<Record<string, boolean>>({});

  const toggleTopic = (topic: string) => {
    setCompleted((prev) => ({
      ...prev,
      [topic]: !prev[topic],
    }));
  };

  const completedCount = useMemo(() => {
    return allTopics.filter((topic) => completed[topic]).length;
  }, [completed, allTopics]);

  const percentage = Math.round((completedCount / allTopics.length) * 100);

  const achievements = [];

  if (percentage >= 25) achievements.push('🏅 Beginner');

  if (percentage >= 50) achievements.push('🥈 Consistent Learner');

  if (percentage >= 75) achievements.push('🥇 Placement Ready');

  if (percentage === 100) achievements.push('🚀 Career Ready');

  return (
    <section className="progress-section">
      <div className="section-title">
        <h2>
          <FaTrophy />
          Learning Progress
        </h2>

        <p>Track every completed topic and monitor your roadmap progress.</p>
      </div>

      <div className="progress-wrapper">
        <motion.div
          className="progress-circle-card"
          initial={{
            opacity: 0,
            scale: 0.8,
          }}
          whileInView={{
            opacity: 1,
            scale: 1,
          }}
        >
          <div
            className="progress-circle"
            style={{
              background: `conic-gradient(
              #2563eb ${percentage * 3.6}deg,
              #dbeafe 0deg
              )`,
            }}
          >
            <div className="progress-inner">
              <h1>{percentage}%</h1>

              <span>Completed</span>
            </div>
          </div>

          <div className="progress-stats">
            <div>
              <strong>{completedCount}</strong>

              <span>Finished</span>
            </div>

            <div>
              <strong>{allTopics.length}</strong>

              <span>Total</span>
            </div>
          </div>
        </motion.div>

        <div className="checklist-card">
          <h3>Checklist</h3>

          <div className="checklist">
            {allTopics.map((topic) => (
              <div
                key={topic}
                className="check-item"
                onClick={() => toggleTopic(topic)}
              >
                {completed[topic] ? (
                  <FaCheckCircle className="done" />
                ) : (
                  <FaRegCircle className="pending" />
                )}

                <span>{topic}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="achievement-section">
        <h3>
          <FaStar />
          Achievements
        </h3>

        <div className="achievement-grid">
          {achievements.length === 0 ? (
            <div className="achievement-card">
              Complete 25% to unlock your first badge.
            </div>
          ) : (
            achievements.map((badge) => (
              <motion.div
                key={badge}
                className="achievement-card"
                whileHover={{
                  y: -6,
                }}
              >
                {badge}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
