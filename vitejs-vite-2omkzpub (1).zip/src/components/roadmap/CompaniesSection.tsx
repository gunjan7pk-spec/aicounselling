import { motion } from 'framer-motion';
import { FaBuilding } from 'react-icons/fa';
import type { RoadmapData } from '../../types/roadmap';

interface Props {
  roadmap: RoadmapData;
}

export default function CompaniesSection({ roadmap }: Props) {
  return (
    <section className="roadmap-section">
      <div className="section-title">
        <FaBuilding />
        <h2>Top Hiring Companies</h2>
      </div>

      <div className="companies-grid">
        {roadmap.companies.map((company, index) => (
          <motion.div
            key={company.name}
            className="company-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.4,
              delay: index * 0.08,
            }}
          >
            <h3>{company.name}</h3>

            <p>{company.role}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
