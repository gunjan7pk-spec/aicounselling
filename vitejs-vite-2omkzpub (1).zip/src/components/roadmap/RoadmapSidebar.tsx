import { useState, useEffect } from 'react';
import {
  FaHome,
  FaCode,
  FaProjectDiagram,
  FaCertificate,
  FaBuilding,
  FaBookOpen,
  FaChartLine,
  FaTasks,
  FaRobot,
} from 'react-icons/fa';

const menuItems = [
  { id: 'overview', label: 'Overview', icon: <FaHome /> },
  { id: 'skills', label: 'Skills', icon: <FaCode /> },
  { id: 'timeline', label: 'Roadmap', icon: <FaBookOpen /> },
  { id: 'projects', label: 'Projects', icon: <FaProjectDiagram /> },
  { id: 'certifications', label: 'Certificates', icon: <FaCertificate /> },
  { id: 'companies', label: 'Companies', icon: <FaBuilding /> },
  { id: 'resources', label: 'Resources', icon: <FaBookOpen /> },
  { id: 'salary', label: 'Salary', icon: <FaChartLine /> },
  { id: 'progress', label: 'Progress', icon: <FaTasks /> },
  { id: 'mentor', label: 'AI Mentor', icon: <FaRobot /> },
];

export default function RoadmapSidebar() {
  const [active, setActive] = useState('overview');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      {
        threshold: 0.4,
      }
    );

    menuItems.forEach((item) => {
      const section = document.getElementById(item.id);

      if (section) {
        observer.observe(section);
      }
    });

    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  };

  return (
    <aside className="roadmap-sidebar">
      <div className="sidebar-logo">
        <h2>CareerPilot AI</h2>

        <span>Your Learning Guide</span>
      </div>

      <nav>
        {menuItems.map((item) => (
          <button
            key={item.id}
            className={`sidebar-item ${active === item.id ? 'active' : ''}`}
            onClick={() => scrollTo(item.id)}
          >
            <span className="sidebar-icon">{item.icon}</span>

            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="progress-circle">
          <div className="circle-inner">
            <h3>28%</h3>

            <span>Done</span>
          </div>
        </div>

        <p>Keep learning every day 🚀</p>
      </div>
    </aside>
  );
}
