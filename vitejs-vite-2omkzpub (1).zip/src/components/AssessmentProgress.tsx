interface AssessmentProgressProps {
  currentStep: number;
  totalSteps: number;
}

export default function AssessmentProgress({
  currentStep,
  totalSteps,
}: AssessmentProgressProps) {
  const percentage = (currentStep / totalSteps) * 100;

  return (
    <div className="assessment-progress">
      <div className="progress-top">
        <span>Step {currentStep}</span>

        <span>{totalSteps} Questions</span>
      </div>

      <div className="progress-bar">
        <div
          className="progress-fill"
          style={{
            width: `${percentage}%`,
          }}
        />
      </div>

      <p>{Math.round(percentage)}% Completed</p>
    </div>
  );
}
