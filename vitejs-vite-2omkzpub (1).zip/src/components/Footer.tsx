import '../styles/Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <h3>CareerPilot AI</h3>
      <p>Helping students choose the right career with AI.</p>

      <p className="copyright">© 2026 CareerPilot AI. All Rights Reserved.</p>
    </footer>
  );
}
