import '../styles/Features.css';

function Features() {
  return (
    <section className="features">
      <h2>Our Features</h2>

      <div className="feature-grid">
        <div className="feature-card">
          <h3>🤖 AI Career Recommendation</h3>
          <p>Get the best career based on your interests and skills.</p>
        </div>

        <div className="feature-card">
          <h3>📄 Resume Analyzer</h3>
          <p>Upload your resume and receive instant AI feedback.</p>
        </div>

        <div className="feature-card">
          <h3>📚 Learning Roadmap</h3>
          <p>AI creates a personalized roadmap for your dream career.</p>
        </div>

        <div className="feature-card">
          <h3>💼 Skill Gap Analysis</h3>
          <p>Know which skills you need before applying for jobs.</p>
        </div>
      </div>
    </section>
  );
}

export default Features;
