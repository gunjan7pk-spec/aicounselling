import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

import {
  FaHome,
  FaClipboardCheck,
  FaFileAlt,
  FaLightbulb,
  FaUserCircle,
  FaSignInAlt,
  FaUserPlus,
  FaSignOutAlt,
} from 'react-icons/fa';

import '../styles/Navbar.css';

export default function Navbar() {
  const { user, logout } = useAuth();

  const location = useLocation();

  return (
    <nav className="navbar">
      <Link to="/" className="logo">
        Career<span>Pilot</span> AI
      </Link>

      <ul className="nav-links">
        <li className={location.pathname === '/' ? 'active' : ''}>
          <Link to="/">
            <FaHome />
            Home
          </Link>
        </li>

        <li className={location.pathname === '/Assessment' ? 'active' : ''}>
          <Link to="/Assessment">
            <FaClipboardCheck className="assessment-icon" />
            Assessment
          </Link>
        </li>

        <li className={location.pathname === '/ResumeAnalyzer' ? 'active' : ''}>
          <Link to="/ResumeAnalyzer">
            <FaFileAlt className="resume-icon" />
            Resume
          </Link>
        </li>

        <li
          className={location.pathname === '/Recommendations' ? 'active' : ''}
        >
          <Link to="/Recommendations">
            <FaLightbulb className="bulb-icon" />
            Recommendations
          </Link>
        </li>

        {user ? (
          <>
            <li className="profile-link">
              <Link to="/profile">
                <FaUserCircle className="profile-icon" />

                {user.displayName || 'Profile'}
              </Link>
            </li>

            <li>
              <button className="logout-btn" onClick={logout}>
                <FaSignOutAlt />
                Logout
              </button>
            </li>
          </>
        ) : (
          <>
            <li>
              <Link className="login-btn" to="/Login">
                <FaSignInAlt />
                Login
              </Link>
            </li>

            <li>
              <Link className="register-btn" to="/Register">
                <FaUserPlus />
                Register
              </Link>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}
