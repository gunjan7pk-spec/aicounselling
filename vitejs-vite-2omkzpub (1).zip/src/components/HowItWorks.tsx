import '../styles/HowItWorks.css';

export default function HowItWorks() {
  return (
    <section className="how-it-works">
      <h2>How It Works</h2>

      <div className="steps">
        <div className="step">
          <h3>1. Sign Up</h3>
          <p>Create your account.</p>
        </div>

        <div className="step">
          <h3>2. Take Assessment</h3>
          <p>Answer AI-powered career questions.</p>
        </div>

        <div className="step">
          <h3>3. Get Recommendations</h3>
          <p>Receive personalized career suggestions.</p>
        </div>
      </div>
    </section>
  );
}
