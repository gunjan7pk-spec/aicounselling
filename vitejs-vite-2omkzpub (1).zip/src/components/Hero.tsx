import { Link } from 'react-router-dom';
import '../styles/Hero.css';

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-left">
        <span className="hero-badge">🚀 AI Powered Career Guidance</span>

        <h1>
          Discover Your
          <span> Perfect Career</span>
          with Artificial Intelligence
        </h1>

        <p>
          CareerPilot AI analyzes your personality, skills, interests and resume
          to recommend the best career path with personalized roadmaps.
        </p>

        <div className="hero-buttons">
          <Link to="/assessment">
            <button className="primary-btn">Start Assessment</button>
          </Link>

          <Link to="/resume">
            <button className="secondary-btn">Analyze Resume</button>
          </Link>
        </div>
      </div>

      <div className="hero-right">
        <div className="glass-card">
          <h2>Career Match</h2>

          <div className="match-score">94%</div>

          <div className="career-list">
            <div>
              <span>AI Engineer</span>
              <strong>96%</strong>
            </div>

            <div>
              <span>Software Engineer</span>
              <strong>93%</strong>
            </div>

            <div>
              <span>Data Scientist</span>
              <strong>91%</strong>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
