import Navbar from './components/Navbar';
import AppRoutes from './AppRoutes';
import './App.css';

function App() {
  return (
    <>
      <Navbar />

      <div className="content-wrapper">
        <AppRoutes />
      </div>
    </>
  );
}

export default App;
