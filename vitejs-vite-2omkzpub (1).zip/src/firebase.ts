import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyB3m-eMEXQzY3yMEngp5g_tVknnGzR9V_0',
  authDomain: 'careerpilot-ai-8dd8e.firebaseapp.com',
  projectId: 'careerpilot-ai-8dd8e',
  storageBucket: 'careerpilot-ai-8dd8e.firebasestorage.app',
  messagingSenderId: '617602306027',
  appId: '1:617602306027:web:6b5b5607ccb97fd9cf13ae',
};

export const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

export const db = getFirestore(app);

export const storage = getStorage(app);
