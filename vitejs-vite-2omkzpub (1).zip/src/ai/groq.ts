import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: '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',

  dangerouslyAllowBrowser: true,
});

export async function generateCareerAdvice(answers: any) {
  const response = await groq.chat.completions.create({
    model: 'llama-3.1-8b-instant',

    messages: [
      {
        role: 'system',

        content: `
You are an AI career counselor.

Analyze the student's assessment.

Return ONLY JSON.
Do not use markdown.
Do not add explanations outside JSON.

Use this exact format:

{
 "career": "Best career name",
 "match": "percentage",
 "why": [
   "reason 1",
   "reason 2",
   "reason 3"
 ],
 "skills": [
   "skill 1",
   "skill 2",
   "skill 3",
   "skill 4",
   "skill 5"
 ],
 "roadmap": [
   "step 1",
   "step 2",
   "step 3",
   "step 4"
 ]
}

`,
      },

      {
        role: 'user',

        content: `
Student assessment answers:

${JSON.stringify(answers)}

`,
      },
    ],

    temperature: 0.7,
  });

  const result = response.choices[0].message.content;

  return result || '{}';
}
