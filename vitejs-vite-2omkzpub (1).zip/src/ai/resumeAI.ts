import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: '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',
  dangerouslyAllowBrowser: true,
});

export async function analyzeResumeAI(resumeText: string) {
  const completion = await groq.chat.completions.create({
    model: 'llama-3.1-8b-instant',

    messages: [
      {
        role: 'system',
        content: `
You are an expert ATS Resume Reviewer.

Return ONLY valid JSON.

Format:

{
"atsScore":"85%",
"strengths":[
"",
"",
""
],
"missingSkills":[
"",
"",
""
],
"suggestions":[
"",
"",
""
],
"jobRoles":[
"",
"",
""
]
}
`,
      },

      {
        role: 'user',
        content: resumeText,
      },
    ],
  });

  return completion.choices[0].message.content || '{}';
}
