import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import {
  MdPsychology,
  MdCheckCircle,
  MdLightbulb,
  MdWork,
  MdRocketLaunch,
  MdStars,
  MdTrendingUp,
} from 'react-icons/md';

import { generateCareerAdvice } from '../ai/groq';

import '../styles/Results.css';

interface AIResult {
  career: string;
  match: string;
  why: string[];
  skills: string[];
  roadmap: string[];
}

export default function Results() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);

  const [aiResult, setAiResult] = useState<AIResult>({
    career: '',
    match: '',
    why: [],
    skills: [],
    roadmap: [],
  });

  useEffect(() => {
    async function getAIResult() {
      try {
        const savedAnswers = localStorage.getItem('assessmentAnswers');

        const answers = savedAnswers ? JSON.parse(savedAnswers) : {};

        const response = await generateCareerAdvice(answers);

        const cleanJSON = response
          .replace(/```json/g, '')
          .replace(/```/g, '')
          .trim();

        const parsed = JSON.parse(cleanJSON);

        setAiResult(parsed);
      } catch (error) {
        console.error(error);

        setAiResult({
          career: 'Software Engineer',
          match: '90%',
          why: [
            'Excellent analytical thinking',
            'Strong logical reasoning',
            'Fast learner',
          ],
          skills: ['React', 'JavaScript', 'Node.js', 'Git', 'Communication'],
          roadmap: [
            'Master JavaScript',
            'Build React Projects',
            'Learn Backend',
            'Prepare for Interviews',
          ],
        });
      }

      setLoading(false);
    }

    getAIResult();
  }, []);

  function restartAssessment() {
    localStorage.removeItem('assessmentCompleted');
    localStorage.removeItem('assessmentAnswers');

    navigate('/Assessment');
  }

  if (loading) {
    return (
      <div className="results-page">
        <div className="loading-card">
          <MdPsychology className="brain" />

          <h1>AI is analysing your profile...</h1>

          <p>Please wait a few seconds.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="results-page">
      <div className="results-container">
        <div className="results-header">
          <span className="badge">🤖 Powered by Groq AI</span>

          <h1>Your Career Intelligence Report</h1>

          <p>Personalized recommendations based on your assessment.</p>
        </div>

        <div className="hero-card">
          <div>
            <h3>Best Career Match</h3>

            <h1>{aiResult.career}</h1>
          </div>

          <div className="score-circle">
            <MdStars />

            <span>{aiResult.match}</span>
          </div>
        </div>

        <div className="grid">
          <div className="card">
            <div className="card-title">
              <MdWork />

              <h2>Why this Career?</h2>
            </div>

            {aiResult.why.map((item, index) => (
              <div className="list-item" key={index}>
                <MdCheckCircle />
                <span>{item}</span>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-title">
              <MdLightbulb />

              <h2>Skills to Learn</h2>
            </div>

            <div className="skills">
              {aiResult.skills.map((skill, index) => (
                <span className="skill-chip" key={index}>
                  {skill}
                </span>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="card-title">
              <MdRocketLaunch />

              <h2>Learning Roadmap</h2>
            </div>

            <div className="roadmap">
              {aiResult.roadmap.map((step, index) => (
                <div className="roadmap-item" key={index}>
                  <div className="roadmap-number">{index + 1}</div>

                  <div className="roadmap-text">{step}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-title">
              <MdTrendingUp />

              <h2>AI Career Advice</h2>
            </div>

            <div className="advice-box">
              <p>
                Based on your assessment, you have strong potential in
                <strong> {aiResult.career}</strong>.
              </p>

              <p>
                Continue improving the skills listed above, work on real-world
                projects, build a strong portfolio, and practice interview
                questions regularly.
              </p>

              <p>
                Stay consistent for the next 6–12 months to maximize your career
                opportunities.
              </p>
            </div>
          </div>
        </div>

        <div className="bottom-buttons">
          <button className="restart-btn" onClick={restartAssessment}>
            Restart Assessment
          </button>

          <button className="download-btn" onClick={() => window.print()}>
            Download Report
          </button>
        </div>
      </div>
    </div>
  );
}
