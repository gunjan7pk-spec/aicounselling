import { useAuth } from '../auth/AuthContext';
import { useNavigate } from 'react-router-dom';

import {
  FaUser,
  FaEnvelope,
  FaCheckCircle,
  FaChartLine,
  FaFileAlt,
  FaBrain,
} from 'react-icons/fa';

import '../styles/Profile.css';

export default function Profile() {
  const { user, logout } = useAuth();

  const navigate = useNavigate();

  const userName = user?.displayName || user?.email?.split('@')[0] || 'User';

  async function handleLogout() {
    await logout();

    navigate('/');
  }

  return (
    <div className="profile-page">
      <div className="profile-card">
        <div className="profile-top">
          <div className="avatar">{userName.charAt(0).toUpperCase()}</div>

          <h1>👋 Hi, {userName}!</h1>

          <p>AI Career Explorer 🚀</p>
        </div>

        <div className="user-info">
          <div className="info-card">
            <FaUser />

            <div>
              <span>Name</span>

              <h3>{userName}</h3>
            </div>
          </div>

          <div className="info-card">
            <FaEnvelope />

            <div>
              <span>Email</span>

              <h3>{user?.email}</h3>
            </div>
          </div>

          <div className="info-card">
            <FaCheckCircle />

            <div>
              <span>Status</span>

              <h3>Verified</h3>
            </div>
          </div>
        </div>

        <div className="career-stats">
          <div>
            <FaChartLine />

            <h2>0</h2>

            <p>Assessments</p>
          </div>

          <div>
            <FaFileAlt />

            <h2>0%</h2>

            <p>Resume Score</p>
          </div>

          <div>
            <FaBrain />

            <h2>AI</h2>

            <p>Career Match</p>
          </div>
        </div>

        <button className="logout-profile" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </div>
  );
}
