import { Link } from 'react-router-dom';
import '../styles/Dashboard.css';

export default function Dashboard() {
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Welcome to CareerPilot AI 👋</h1>
        <p>Your AI-powered career companion</p>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card">
          <h2>🧠 Career Assessment</h2>
          <p>Discover your ideal career path.</p>
          <Link to="/assessment">
            <button>Start Assessment</button>
          </Link>
        </div>

        <div className="dashboard-card">
          <h2>📄 Resume Analyzer</h2>
          <p>Check ATS score & improve resume.</p>
          <Link to="/resume">
            <button>Analyze Resume</button>
          </Link>
        </div>

        <div className="dashboard-card">
          <h2>🎯 Career Recommendations</h2>
          <p>Explore careers matching your profile.</p>
          <Link to="/recommendations">
            <button>View Careers</button>
          </Link>
        </div>

        <div className="dashboard-card">
          <h2>📊 Results</h2>
          <p>View your latest assessment report.</p>
          <Link to="/results">
            <button>Open Report</button>
          </Link>
        </div>
      </div>
    </div>
  );
}
