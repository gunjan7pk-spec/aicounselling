import { useState } from 'react';
import '../styles/ResumeAnalyzer.css';

import {
  MdCloudUpload,
  MdPsychology,
  MdStars,
  MdCheckCircle,
  MdWarning,
  MdWork,
  MdTrendingUp,
  MdDescription,
  MdAutoAwesome,
  MdInsertDriveFile,
} from 'react-icons/md';

import { extractResumeText } from '../utils/resumeText';
import { analyzeResumeAI } from '../ai/resumeAI';

interface ResumeReport {
  atsScore: string;
  strengths: string[];
  missingSkills: string[];
  suggestions: string[];
  jobRoles: string[];
}

export default function ResumeAnalyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<ResumeReport | null>(null);
  const [dragActive, setDragActive] = useState(false);

  function handleFile(file: File) {
    setFile(file);
    setReport(null);
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files?.length) {
      handleFile(e.target.files[0]);
    }
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragActive(false);

    if (e.dataTransfer.files.length) {
      handleFile(e.dataTransfer.files[0]);
    }
  }

  async function analyzeResume() {
    if (!file) {
      alert('Please upload your resume.');
      return;
    }

    setLoading(true);

    try {
      const resumeText = await extractResumeText(file);

      const response = await analyzeResumeAI(resumeText);

      const clean = response
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();

      const parsed = JSON.parse(clean);

      setReport(parsed);
    } catch (error) {
      console.error(error);
      alert('Unable to analyze resume.');
    }

    setLoading(false);
  }

  return (
    <div className="resume-page">
      <div className="resume-container">
        <section className="resume-hero">
          <div>
            <div className="resume-hero-badge">
              <MdAutoAwesome />
              AI Powered Resume Analysis
            </div>

            <h1>Resume Analyzer</h1>

            <p>
              Upload your resume and receive ATS score, career suggestions,
              missing skills and AI recommendations in seconds.
            </p>
          </div>

          <div className="resume-hero-right">
            <MdPsychology />
          </div>
        </section>
        <section
          className={dragActive ? 'upload-card active' : 'upload-card'}
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
        >
          <MdCloudUpload className="upload-icon" />

          <h2>Upload Your Resume</h2>

          <p>Drag & Drop or Choose Resume</p>

          <label htmlFor="resume">Choose Resume</label>

          <input
            id="resume"
            type="file"
            accept=".pdf,.doc,.docx,.txt"
            onChange={handleChange}
          />

          {file && (
            <div className="selected-file">
              <MdInsertDriveFile />
              <span>{file.name}</span>
            </div>
          )}

          <button
            className="analyze-btn"
            onClick={analyzeResume}
            disabled={loading}
          >
            {loading ? 'Analyzing Resume...' : 'Analyze Resume'}
          </button>
        </section>

        {loading && (
          <section className="loading-section">
            <div className="loader"></div>

            <h2>🤖 AI is reading your resume...</h2>

            <p>
              Calculating ATS score • Finding missing skills • Recommending
              careers
            </p>
          </section>
        )}

        {report && (
          <>
            <section className="summary-grid">
              <div className="summary-card ats">
                <div className="circle">
                  <MdStars />
                  <span>{report.atsScore}</span>
                </div>

                <h3>ATS Score</h3>

                <p>
                  Overall compatibility of your resume with modern ATS systems.
                </p>
              </div>

              <div className="summary-card">
                <MdWork className="summary-icon" />

                <h3>Recommended Roles</h3>

                <div className="chips">
                  {report.jobRoles.map((role, index) => (
                    <span key={index} className="chip">
                      {role}
                    </span>
                  ))}
                </div>
              </div>
            </section>

            <section className="analysis-grid">
              <div className="analysis-card">
                <div className="card-header">
                  <MdCheckCircle />
                  <h2>Strengths</h2>
                </div>

                {report.strengths.map((item, index) => (
                  <div className="list-item" key={index}>
                    <span className="success-dot">✓</span>
                    <p>{item}</p>
                  </div>
                ))}
              </div>

              <div className="analysis-card">
                <div className="card-header">
                  <MdWarning />
                  <h2>Missing Skills</h2>
                </div>

                <div className="chips">
                  {report.missingSkills.map((item, index) => (
                    <span key={index} className="chip danger">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
              <div className="analysis-card">
                <div className="card-header">
                  <MdTrendingUp />
                  <h2>AI Suggestions</h2>
                </div>

                {report.suggestions.map((item, index) => (
                  <div className="list-item" key={index}>
                    <span className="idea-dot">💡</span>
                    <p>{item}</p>
                  </div>
                ))}
              </div>

              <div className="analysis-card">
                <div className="card-header">
                  <MdDescription />
                  <h2>Career Growth Roadmap</h2>
                </div>

                <div className="roadmap">
                  <div className="roadmap-item">
                    <div className="road-number">1</div>

                    <div>
                      <h4>Improve Resume</h4>

                      <p>
                        Add measurable achievements, certifications and GitHub
                        profile.
                      </p>
                    </div>
                  </div>

                  <div className="roadmap-item">
                    <div className="road-number">2</div>

                    <div>
                      <h4>Learn Missing Skills</h4>

                      <p>Focus on the skills highlighted by the AI analysis.</p>
                    </div>
                  </div>

                  <div className="roadmap-item">
                    <div className="road-number">3</div>

                    <div>
                      <h4>Build Portfolio</h4>

                      <p>
                        Create 5–10 real-world projects and deploy them online.
                      </p>
                    </div>
                  </div>

                  <div className="roadmap-item">
                    <div className="road-number">4</div>

                    <div>
                      <h4>Start Applying</h4>

                      <p>
                        Apply for internships and entry-level jobs consistently.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="bottom-actions">
              <button
                className="resume-secondary-btn"
                onClick={() => window.print()}
              >
                📄 Download Report
              </button>

              <button
                className="resume-primary-btn"
                onClick={() => {
                  setReport(null);
                  setFile(null);
                }}
              >
                🔄 Analyze Another Resume
              </button>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
