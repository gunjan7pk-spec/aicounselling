import { useNavigate } from 'react-router-dom';
import {
  FaArrowRight,
  FaBriefcase,
  FaChartLine,
  FaBuilding,
  FaCertificate,
} from 'react-icons/fa';
import '../styles/Recommendations.css';

interface Career {
  id: number;
  title: string;
  match: number;
  salary: string;
  growth: string;
  skills: string[];
}

const careers: Career[] = [
  {
    id: 1,
    title: 'AI Engineer',
    match: 96,
    salary: '₹12–35 LPA',
    growth: 'Excellent',
    skills: ['Python', 'Machine Learning', 'TensorFlow', 'Deep Learning'],
  },
  {
    id: 2,
    title: 'Software Engineer',
    match: 93,
    salary: '₹8–25 LPA',
    growth: 'High',
    skills: ['JavaScript', 'React', 'Node.js', 'Git'],
  },
  {
    id: 3,
    title: 'Data Scientist',
    match: 91,
    salary: '₹10–30 LPA',
    growth: 'Excellent',
    skills: ['Python', 'SQL', 'Statistics', 'Pandas'],
  },
  {
    id: 4,
    title: 'UI/UX Designer',
    match: 88,
    salary: '₹7–18 LPA',
    growth: 'High',
    skills: ['Figma', 'Wireframing', 'Prototyping', 'UX Research'],
  },
];

export default function Recommendations() {
  const navigate = useNavigate();

  return (
    <div className="recommend-page">
      <section className="recommend-hero">
        <span className="recommend-badge">🤖 AI Powered Recommendation</span>

        <h1>Your Career Recommendations</h1>

        <p>
          Based on your assessment and resume analysis, CareerPilot AI
          recommends the following career paths specially for you.
        </p>
      </section>

      <section className="recommend-best-card">
        <div>
          <h2>{careers[0].title}</h2>

          <div className="recommend-match-score">
            ⭐ {careers[0].match}% Match
          </div>

          <div className="recommend-info">
            <div>
              <FaBriefcase />
              <span>{careers[0].salary}</span>
            </div>

            <div>
              <FaChartLine />
              <span>{careers[0].growth}</span>
            </div>
          </div>
        </div>

        <button
          className="recommend-roadmap-btn"
          onClick={() =>
            navigate('/roadmap', {
              state: {
                career: careers[0],
              },
            })
          }
        >
          View Full Roadmap
          <FaArrowRight />
        </button>
      </section>

      <section className="recommend-grid">
        {careers.map((career) => (
          <div className="recommend-card" key={career.id}>
            <h2>{career.title}</h2>

            <div className="recommend-match">{career.match}% Match</div>

            <p className="recommend-salary">
              <strong>Salary:</strong> {career.salary}
            </p>

            <p className="recommend-growth">
              <strong>Growth:</strong> {career.growth}
            </p>

            <div className="recommend-skills">
              <h4>Required Skills</h4>

              <div className="recommend-skill-list">
                {career.skills.map((skill) => (
                  <span key={skill} className="recommend-skill-chip">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <button
              className="recommend-view-btn"
              onClick={() =>
                navigate('/roadmap', {
                  state: {
                    career,
                  },
                })
              }
            >
              View Roadmap
            </button>
          </div>
        ))}
      </section>

      <section className="recommend-companies">
        <h2>
          <FaBuilding />
          Top Hiring Companies
        </h2>

        <div className="recommend-company-list">
          <span className="recommend-company-chip">Google</span>
          <span className="recommend-company-chip">Microsoft</span>
          <span className="recommend-company-chip">Amazon</span>
          <span className="recommend-company-chip">Meta</span>
          <span className="recommend-company-chip">Adobe</span>
          <span className="recommend-company-chip">Infosys</span>
          <span className="recommend-company-chip">TCS</span>
          <span className="recommend-company-chip">Accenture</span>
        </div>
      </section>

      <section className="recommend-certifications">
        <h2>
          <FaCertificate />
          Recommended Certifications
        </h2>

        <div className="recommend-cert-grid">
          <div className="recommend-cert-card">Google AI Essentials</div>

          <div className="recommend-cert-card">AWS Cloud Practitioner</div>

          <div className="recommend-cert-card">TensorFlow Developer</div>

          <div className="recommend-cert-card">Microsoft Azure AI</div>

          <div className="recommend-cert-card">IBM Data Science</div>

          <div className="recommend-cert-card">Meta Front-End Professional</div>
        </div>
      </section>
      <section className="recommend-actions">
        <button
          className="recommend-primary-btn"
          onClick={() => navigate('/assessment')}
        >
          Take Assessment Again
        </button>

        <button
          className="recommend-secondary-btn"
          onClick={() => navigate('/resume')}
        >
          Analyze Resume Again
        </button>
      </section>
    </div>
  );
}
