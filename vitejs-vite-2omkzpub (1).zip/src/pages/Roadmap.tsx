import { useLocation } from 'react-router-dom';
import { roadmapData } from '../data/roadmap';

import RoadmapHero from '../components/roadmap/RoadmapHero';
import RoadmapSidebar from '../components/roadmap/RoadmapSidebar';
import SemesterTimeline from '../components/roadmap/SemesterTimeline';
import SkillsSection from '../components/roadmap/SkillsSection';
import ProjectsSection from '../components/roadmap/ProjectsSection';
import CertificationsSection from '../components/roadmap/CertificationsSection';
import CompaniesSection from '../components/roadmap/CompaniesSection';
import ResourcesSection from '../components/roadmap/ResourcesSection';
import SalaryTimeline from '../components/roadmap/SalaryTimeline';
import ProgressTracker from '../components/roadmap/ProgressTracker';
import AIMentor from '../components/roadmap/AIMentor';
import FooterCTA from '../components/roadmap/FooterCTA';

import '../styles/roadmap/Roadmap.css';

export default function Roadmap() {
  const { state } = useLocation();

  const careerTitle =
    state?.career?.title && state.career.title in roadmapData
      ? (state.career.title as keyof typeof roadmapData)
      : 'AI Engineer';

  const roadmap = roadmapData[careerTitle];

  return (
    <div className="roadmap-layout">
      <RoadmapSidebar />

      <main className="roadmap-content">
        <section id="overview">
          <RoadmapHero roadmap={roadmap} />
        </section>

        <section id="skills">
          <SkillsSection roadmap={roadmap} />
        </section>

        <section id="timeline">
          <SemesterTimeline roadmap={roadmap} />
        </section>

        <section id="projects">
          <ProjectsSection roadmap={roadmap} />
        </section>

        <section id="certifications">
          <CertificationsSection roadmap={roadmap} />
        </section>

        <section id="companies">
          <CompaniesSection roadmap={roadmap} />
        </section>

        <section id="resources">
          <ResourcesSection roadmap={roadmap} />
        </section>

        <section id="salary">
          <SalaryTimeline roadmap={roadmap} />
        </section>

        <section id="progress">
          <ProgressTracker roadmap={roadmap} />
        </section>

        <section id="mentor">
          <AIMentor roadmap={roadmap} />
        </section>

        <FooterCTA />
      </main>
    </div>
  );
}
