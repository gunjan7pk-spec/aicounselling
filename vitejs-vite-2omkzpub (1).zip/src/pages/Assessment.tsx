import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { questions } from '../data/questions';
import AssessmentProgress from '../components/AssessmentProgress';

import '../styles/Assessment.css';

export default function Assessment() {
  const navigate = useNavigate();

  useEffect(() => {
    const completed = localStorage.getItem('assessmentCompleted');

    if (completed === 'true') {
      navigate('/Results');
    }
  }, [navigate]);

  const [currentQuestion, setCurrentQuestion] = useState(0);

  const [answers, setAnswers] = useState<Record<number, any>>({});

  const question = questions[currentQuestion];

  const totalQuestions = questions.length;

  function saveAnswer(value: string) {
    setAnswers((previous) => ({
      ...previous,

      [question.id]: value,
    }));
  }

  function handleCheckbox(option: string) {
    const oldAnswers = Array.isArray(answers[question.id])
      ? answers[question.id]
      : [];

    let newAnswers;

    if (oldAnswers.includes(option)) {
      newAnswers = oldAnswers.filter((item: string) => item !== option);
    } else {
      newAnswers = [...oldAnswers, option];
    }

    setAnswers((previous) => ({
      ...previous,

      [question.id]: newAnswers,
    }));
  }

  function nextQuestion() {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      localStorage.setItem('assessmentCompleted', 'true');

      localStorage.setItem('assessmentAnswers', JSON.stringify(answers));

      navigate('/Results');
    }
  }

  function previousQuestion() {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  }

  return (
    <div className="assessment-page">
      <div className="assessment-card">
        <AssessmentProgress
          currentStep={currentQuestion + 1}
          totalSteps={totalQuestions}
        />

        <h2>{question.category}</h2>

        <h1>{question.question}</h1>

        {question.type === 'text' && (
          <input
            className="assessment-input"
            value={answers[question.id] || ''}
            onChange={(e) => saveAnswer(e.target.value)}
            placeholder="Enter your answer"
          />
        )}

        {question.type === 'radio' && (
          <div className="options">
            {question.options?.map((option) => (
              <button
                key={option}
                className={
                  answers[question.id] === option ? 'option selected' : 'option'
                }
                onClick={() => saveAnswer(option)}
              >
                {option}
              </button>
            ))}
          </div>
        )}

        {question.type === 'checkbox' && (
          <div className="options">
            {question.options?.map((option) => {
              const selectedList = Array.isArray(answers[question.id])
                ? answers[question.id]
                : [];

              const selected = selectedList.includes(option);

              return (
                <button
                  key={option}
                  className={selected ? 'option selected' : 'option'}
                  onClick={() => handleCheckbox(option)}
                >
                  {option}
                </button>
              );
            })}
          </div>
        )}

        {question.type === 'rating' && (
          <div className="rating">
            {[1, 2, 3, 4, 5].map((number) => (
              <button
                key={number}
                className={
                  answers[question.id] === String(number)
                    ? 'rating-btn active'
                    : 'rating-btn'
                }
                onClick={() => saveAnswer(String(number))}
              >
                {number}
              </button>
            ))}
          </div>
        )}

        <div className="assessment-buttons">
          <button disabled={currentQuestion === 0} onClick={previousQuestion}>
            Previous
          </button>

          <button onClick={nextQuestion}>
            {currentQuestion === totalQuestions - 1 ? 'Finish' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
}
